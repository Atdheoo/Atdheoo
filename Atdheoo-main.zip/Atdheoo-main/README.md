- 👋 Hi, I’m @Atdheoo
- 👀 I’m interested in programming
- 🌱 I’m currently learning python
- 💞️ I’m looking to collaborate on team
- 📫 How to reach me capacity

<!---
Atdheoo/Atdheoo is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
